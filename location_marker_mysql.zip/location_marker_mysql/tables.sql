create table markers(
        id      int             primary key auto_increment,
        lat     varchar(100),
        lng     varchar(100)
);

