<?php
        const DB_NAME="location_marker_mysql";
        const DB_USER="root";
        const DB_PASS="mysql";
        const DB_HOST="localhost";

